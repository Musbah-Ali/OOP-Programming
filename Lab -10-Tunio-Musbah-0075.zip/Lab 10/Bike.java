class Bike implements Vehicle{
	
	void start(){
		System.out.println("Bike is Started .");
	}

	 void stop(){
	 	System.out.println("Bike is stopped .");
	 }
}
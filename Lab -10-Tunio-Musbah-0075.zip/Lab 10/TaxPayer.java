interface TaxPayer{
	
		void payTax();
	}
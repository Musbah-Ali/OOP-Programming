class Duck implements Flyable ,Swimmable{
	
	void fly(){
		System.out.println("Flying ... ");
	}

	void swim(){
		System.out.println("Duck can also swim ...");
	}

	public static void main(String[] args) {
		Duck d = new Duck();
		d.swim(); 
		d.fly();
			
		
	}

}
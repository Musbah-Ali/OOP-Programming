class Main{
	public static void main(String[] args) {
		Dog d = new Dog();
		Cat c= new Cat();

		c.makeSound();
		d.makeSound();
	
	}
}
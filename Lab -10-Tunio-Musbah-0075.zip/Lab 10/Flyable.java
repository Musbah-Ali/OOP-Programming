interface Flyable{

	void fly();

}
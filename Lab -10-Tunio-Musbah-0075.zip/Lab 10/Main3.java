class Main3{

public static void main(String[] args) {
    
		FullTimeEmployee fullTime = new FullTimeEmployee("Zahid", "F24-ARI", 5000);

        PartTimeEmployee partTime = new PartTimeEmployee("Rafique","F23-ARI",80, 20);

        System.out.println("Salary of " + fullTime.name + ": PKR" + fullTime.calculateSalary());
        fullTime.payTax();

        System.out.println("Salary of " + partTime.name + ": PKR" + partTime.calculateSalary());
        partTime.payTax();
    
	}	
}
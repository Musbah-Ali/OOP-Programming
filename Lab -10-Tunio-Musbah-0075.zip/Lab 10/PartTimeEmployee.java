class PartTimeEmployee extends Employee implements TaxPayer{
	double hoursWorked;
	double rateHoursWorked;

	PartTimeEmployee(String name,String id,double hoursWorked,double rateHoursWorked){
		super(name,id);
		this.hoursWorked=hoursWorked;
		this.rateHoursWorked=rateHoursWorked;
	}
	
	public double calculateSalary(){
		return hoursWorked*rateHoursWorked;
	}

	public void payTax(){
		 double salary = calculateSalary();
        System.out.println(name + " (Part-Time) paid tax: $" + (0.1 * salary));
    }	
}
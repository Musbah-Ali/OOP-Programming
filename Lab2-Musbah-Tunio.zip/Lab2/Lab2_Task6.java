 import java.util.Scanner;
class Lab2_Task6{
public static void main(String args []){
Scanner input =new Scanner(System.in);
System.out.println("Enter Your age : ");
int age =input.nextInt();
//For ternary operator syntax .

String result=(age>=18)? "You are eligible for voting . " : " Sorry , You are not eligible for voting .";

System.out.println(result);
}
}
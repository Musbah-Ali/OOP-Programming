import java.util.Scanner;
class Lab2_Task3{
public static void main(String args[]){
Scanner input = new Scanner(System.in);

int row,col;
System.out.println("Enter the number of rows ");
row =input.nextInt();
System.out.println("Enter the number of columns ");
col =input.nextInt();
int arr[][]= new int[row][col] ;
int arr2[][]= new int[row][col];
for(int row =0;row<2;row++)
{
for(int col=0;col<3;col++)
{
arr1[row][col]=input.nextInt();
}

} 

}
}
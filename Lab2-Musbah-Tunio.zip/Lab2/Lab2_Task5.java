import java.util.Scanner;
class Lab2_Task5{
public static void main(String args[]){


int numbers[][]={{1,1,0,0,1},{1,0,1,0,1},{1,0,0,1,1},{1,0,0,0,1}};
int row=4;
int col=5;

for (int i=0; i<row; i++)
{

for (int j=0; j<col; j++)
{ 
System.out.print(numbers[i][j]);

}

System.out.println("   ");
}
}
}